#include "triesite.h"
#include  "fileutils.h"
#include <iostream>

using namespace std;
using namespace Library;

int main()
{
	cout << "Hello, world" << endl;
	triesite site;
	system("pause");	
	return 0;
}